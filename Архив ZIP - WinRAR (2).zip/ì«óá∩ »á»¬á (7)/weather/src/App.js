import './App.css';
import MainBox from './components/MainBox/Mainbox';
function App() {
  return (
    <div className="App">
      <MainBox/>
    </div>
  );
}
export default App;